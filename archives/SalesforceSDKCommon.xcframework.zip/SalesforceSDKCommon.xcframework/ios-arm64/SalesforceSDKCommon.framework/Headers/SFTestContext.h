/*
 Copyright (c) 2015-present, salesforce.com, inc. All rights reserved.
 
 Redistribution and use of this software in source and binary forms, with or without modification,
 are permitted provided that the following conditions are met:
 * Redistributions of source code must retain the above copyright notice, this list of conditions
 and the following disclaimer.
 * Redistributions in binary form must reproduce the above copyright notice, this list of
 conditions and the following disclaimer in the documentation and/or other materials provided
 with the distribution.
 * Neither the name of salesforce.com, inc. nor the names of its contributors may be used to
 endorse or promote products derived from this software without specific prior written
 permission of salesforce.com, inc.
 
 THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS" AND ANY EXPRESS OR
 IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND
 FITNESS FOR A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT OWNER OR
 CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL
 DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE,
 DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY,
 WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY
 WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 */

// This class is intended to be used to set the application in testing context or
// live context. It could be used by application to implement mock logic under 
// testing context so that application can be run without live connection

#import <Foundation/Foundation.h>

NS_ASSUME_NONNULL_BEGIN

/**Helps determine whether we're currently running tests or not.
 */
__attribute__((deprecated("Deprecated in Salesforce Mobile SDK 13.2 and will be removed in Salesforce Mobile SDK 14.0.")));
@interface SFTestContext : NSObject {

}
/**Return YES if is running test
 */
+ (BOOL)isRunningTests;

/**Update SFTestContext to indicate whether it is in testing context or live context
 @param runningTests Yes if code is running under testing context
 */
+ (void)setIsRunningTests:(BOOL)runningTests;

/** Sets an arbitrary object into the test context
 @param object The object or nil to remove the object
 @param key The key
 */
+ (void)setObject:(nullable id)object forKey:(id)key;

/** Returns an arbitrary object from the test context
 @param key The key
 @return The object
 */
+ (id)objectForKey:(id)key;

/** Removes all the stored objects
 */
+ (void)clearObjects;

@end

NS_ASSUME_NONNULL_END
