/*
 Copyright (c) 2012-present, salesforce.com, inc. All rights reserved.
 
 Redistribution and use of this software in source and binary forms, with or without modification,
 are permitted provided that the following conditions are met:
 * Redistributions of source code must retain the above copyright notice, this list of conditions
 and the following disclaimer.
 * Redistributions in binary form must reproduce the above copyright notice, this list of
 conditions and the following disclaimer in the documentation and/or other materials provided
 with the distribution.
 * Neither the name of salesforce.com, inc. nor the names of its contributors may be used to
 endorse or promote products derived from this software without specific prior written
 permission of salesforce.com, inc.
 
 THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS" AND ANY EXPRESS OR
 IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND
 FITNESS FOR A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT OWNER OR
 CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL
 DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE,
 DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY,
 WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY
 WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 */

#import <Foundation/Foundation.h>

NS_ASSUME_NONNULL_BEGIN

@class SFOAuthCoordinator;
@class SFSDKTestCredentialsData;

/**
 This class provides utilities useful to all unit tests based on the Salesforce SDK
 */
@interface TestSetupUtils : NSObject

/**
 Loads a set of auth credentials from the 'ui_test_credentials.json' file located in the bundle associated
 with the given class, and return a dictionary of login info
 @param testClass The class associated with the bundle where the test credentials file lives.
 @return a dictionary of login username, password, url
 */
+ (NSArray *)populateUILoginInfoFromConfigFileForClass:(Class)testClass SFSDK_DEPRECATED(14.0, 15.0, "TestSetupUtils instant login helpers are deprecated and will be removed in 15.0. They are incompatible with DPoP enforcement.");

/**
 Loads a set of auth credentials from the 'test_credentials.json' file located in the bundle associated
 with the given class, and configures SFUserAccountManager and the current account with the data from
 that file.
 @param testClass The class associated with the bundle where the test credentials file lives.
 @return The configuration data used to configure SFUserAccountManager (useful e.g. for hybrid
 apps which need the data to bootstrap SFHybridViewController).
 */
+ (SFSDKTestCredentialsData *)populateAuthCredentialsFromConfigFileForClass:(Class)testClass SFSDK_DEPRECATED(14.0, 15.0, "TestSetupUtils instant login helpers are deprecated and will be removed in 15.0. They are incompatible with DPoP enforcement.");

/**
 Loads a set of auth credentials from the provided JSON string, and configures
 SFUserAccountManager and the current account with the data from that JSON.
 Salesforce Mobile SDK will be initialized while populating test credentials.
 @param testCredentialsJsonString The test credentials JSON as a string.
 @return The configuration data used to configure SFUserAccountManager (useful
 e.g. for hybrid apps which need the data to bootstrap SFHybridViewController).
 */
+ (SFSDKTestCredentialsData *)populateAuthCredentialsFromString:(NSString *)testCredentialsJsonString SFSDK_DEPRECATED(14.0, 15.0, "TestSetupUtils instant login helpers are deprecated and will be removed in 15.0. They are incompatible with DPoP enforcement.");

/**
 Loads a set of auth credentials from the provided JSON string, and configures
 SFUserAccountManager and the current account with the data from that JSON.
 @param testCredentialsJsonString The test credentials JSON as a string.
 @param initializeSdk Indicates if Salesfore Mobile SDK should be initialized
 while populating test credentials.
 @return The configuration data used to configure SFUserAccountManager (useful
 e.g. for hybrid apps which need the data to bootstrap SFHybridViewController).
 */
+ (SFSDKTestCredentialsData *)populateAuthCredentialsFromString:(NSString *)testCredentialsJsonString initializeSdk:(BOOL)initializeSdk SFSDK_DEPRECATED(14.0, 15.0, "TestSetupUtils instant login helpers are deprecated and will be removed in 15.0. They are incompatible with DPoP enforcement.");

/**
 Performs a synchronous refresh of the OAuth credentials, which will stage the
 remaining auth data (access token, User ID, Org ID, etc.) in
 SFUserAccountManager. `populateAuthCredentialsFromConfigFile`
 is required to run once before this method will attempt to refresh authentication.
 The "user did log in" notification will not be posted.
 */
+ (void)synchronousAuthRefresh;

/**
 Performs a synchronous refresh of the OAuth credentials, which will stage the
 remaining auth data (access token, User ID, Org ID, etc.) in
 SFUserAccountManager. `populateAuthCredentialsFromConfigFile`
 is required to run once before this method will attempt to refresh authentication.
 @param postUserDidLogIn Indicates if the "user did log in" notification should
 be posted.
 */
+ (void)synchronousAuthRefreshWithUserDidLoginNotification:(BOOL)postUserDidLogIn;

+ (SFOAuthCredentials *)newClientCredentials;

@end

NS_ASSUME_NONNULL_END
