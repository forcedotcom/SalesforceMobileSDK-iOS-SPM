/*
 SFSDKOAuthConstants.h
 SalesforceSDKCore
 
 Created by Raj Rao on 7/11/19.
 Copyright (c) 2019-present, salesforce.com, inc. All rights reserved.
 
 Redistribution and use of this software in source and binary forms, with or without modification,
 are permitted provided that the following conditions are met:
 * Redistributions of source code must retain the above copyright notice, this list of conditions
 and the following disclaimer.
 * Redistributions in binary form must reproduce the above copyright notice, this list of
 conditions and the following disclaimer in the documentation and/or other materials provided
 with the distribution.
 * Neither the name of salesforce.com, inc. nor the names of its contributors may be used to
 endorse or promote products derived from this software without specific prior written
 permission of salesforce.com, inc.
 
 THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS" AND ANY EXPRESS OR
 IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND
 FITNESS FOR A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT OWNER OR
 CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL
 DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE,
 DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY,
 WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY
 WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 */

#ifndef SFSDKOAuthConstants_h
#define SFSDKOAuthConstants_h

// Private constants
static NSString * const kSFOAuthEndPointAuthorize               = @"/services/oauth2/authorize";    // login flow
static NSString * const kSFOAuthEndPointToken                   = @"/services/oauth2/token";        // token refresh flow
static NSString * const kSFRevokePath                           = @"/services/oauth2/revoke";

// Advanced auth constants
static NSUInteger const kSFOAuthCodeVerifierByteLength          = 128;
static NSString * const kSFOAuthCodeVerifierParamName           = @"code_verifier";
static NSString * const kSFOAuthCodeChallengeParamName          = @"code_challenge";
static NSString * const kSFOAuthDPoPJktParamName                = @"dpop_jkt";

// Native browser (advanced auth) authorize URL params: tell the server why the SDK is using
// native browser login, and carry the SDK user agent string as a query param (the system
// browser's own outbound requests use its own User-Agent header, not the SDK's).
static NSString * const kSFOAuthAuthTriggerParamName             = @"auth_trigger";
static NSString * const kSFOAuthSdkInfoParamName                 = @"sdkInfo";

// auth_trigger values. Priority when more than one applies: LoginForAdmin > MDM > ForceAdvancedAuth > OrgConfig
// (mirrors the B1-B4 app feature marker priority in SFUserAccountManager's computeBMarkerForAuthSession:).
static NSString * const kSFOAuthAuthTriggerOrgConfig             = @"org_config";
static NSString * const kSFOAuthAuthTriggerMDM                   = @"mdm";
static NSString * const kSFOAuthAuthTriggerForceAdvancedAuth     = @"force_advanced_auth";
static NSString * const kSFOAuthAuthTriggerLoginForAdmin         = @"login_for_admin";
static NSString * const kSFOAuthResponseTypeCode                = @"code";
static NSString * const kSFOAuthAccessToken                     = @"access_token";
static NSString * const kSFOAuthClientId                        = @"client_id";
static NSString * const kSFOAuthDeviceId                        = @"device_id";
static NSString * const kSFOAuthCustomPermissions               = @"custom_permissions";
static NSString * const kSFOAuthDisplay                         = @"display";
static NSString * const kSFOAuthDisplayTouch                    = @"touch";
static NSString * const kSFOAuthError                           = @"error";
static NSString * const kSFOAuthErrorDescription                = @"error_description";
static NSString * const kSFOAuthFormat                          = @"format";
static NSString * const kSFOAuthFormatJson                      = @"json";
static NSString * const kSFOAuthGrantType                       = @"grant_type";
static NSString * const kSFOAuthGrantTypeHybridRefresh          = @"hybrid_refresh";
static NSString * const kSFOAuthGrantTypeRefresh                = @"refresh_token";
static NSString * const kSFOAuthId                              = @"id";
static NSString * const kSFOAuthInstanceUrl                     = @"instance_url";
static NSString * const kSFOAuthApiInstanceUrl                  = @"api_instance_url";
static NSString * const kSFOAuthCommunityId                     = @"sfdc_community_id";
static NSString * const kSFOAuthCommunityUrl                    = @"sfdc_community_url";
static NSString * const kSFOAuthIdToken                         = @"id_token";
static NSString * const kSFOAuthIssuedAt                        = @"issued_at";
static NSString * const kSFOAuthRedirectUri                     = @"redirect_uri";
static NSString * const kSFOAuthRefreshToken                    = @"refresh_token";
static NSString * const kSFOAuthResponseType                    = @"response_type";
static NSString * const kSFOAuthResponseTypeHybridToken         = @"hybrid_token";
static NSString * const kSFOAuthResponseTypeToken               = @"token";
static NSString * const kSFOAuthScope                           = @"scope";
static NSString * const kSFOAuthSignature                       = @"signature";
static NSString * const kSFOAuthLightningDomain                 = @"lightning_domain";
static NSString * const kSFOAuthLightningSID                    = @"lightning_sid";
static NSString * const kSFOAuthVFDomain                        = @"visualforce_domain";
static NSString * const kSFOAuthVFSID                           = @"visualforce_sid";
static NSString * const kSFOAuthContentDomain                   = @"content_domain";
static NSString * const kSFOAuthContentSID                      = @"content_sid";
static NSString * const kSFOAuthCSRFToken                       = @"csrf_token";
static NSString * const kSFOAuthCookieClientSrc                 = @"cookie-clientSrc";
static NSString * const kSFOAuthCookieSidClient                 = @"cookie-sid_Client";
static NSString * const kSFOAuthSidCookieName                   = @"sidCookieName";
static NSString * const kSFOAuthParentSid                       = @"parent_sid";
static NSString * const kSFOAuthUiSid                           = @"ui_sid";
static NSString * const kSFOAuthTokenFormat                     = @"token_format";
static NSString * const kSFOAuthTokenType                       = @"token_type";
static NSString * const kSFOAuthDPoPTokenType                   = @"DPoP";
static NSString * const kSFOAuthAttestation                     = @"attestation";
static NSString * const kSFOAuthBeaconChildConsumerKey          = @"auto_installed_app_org_consumer_key";
static NSString * const kSFOAuthBeaconChildConsumerSecret       = @"auto_installed_app_org_consumer_secret";
// TODO: Remove legacy fallback constants once server version 264 has rolled out everywhere.
static NSString * const kSFOAuthLegacyBeaconChildConsumerKey    = @"beacon_child_consumer_key";
static NSString * const kSFOAuthLegacyBeaconChildConsumerSecret = @"beacon_child_consumer_secret";

// Used for the IP bypass flow, Advanced auth flow
static NSString * const kSFOAuthApprovalCode                     = @"code";
static NSString * const kSFOAuthGrantTypeHybridAuthorizationCode = @"hybrid_auth_code";
static NSString * const kSFOAuthGrantTypeAuthorizationCode       = @"authorization_code";

// Native Login constants
static NSString * const kSFOAuthAuthVerificationTypeParamName   = @"Auth-Verification-Type";
static NSString * const kSFOAuthAuthVerificationTypeEmail       = @"email";
static NSString * const kSFOAuthAuthVerificationTypeSms         = @"sms";

static NSString * const kSFOAuthCodeCredentialsParamName        = @"code_credentials";

static NSString * const kSFOAuthRequestTypeParamName            = @"Auth-Request-Type";
static NSString * const kSFOAuthRequestTypeNamedUser            = @"Named-User";
static NSString * const kSFOAuthRequestTypePasswordlessLogin    = @"passwordless-login";
static NSString * const kSFOAuthRequestTypeUserRegistration     = @"user-registration";

static NSString * const kSFOAuthAuthorizationTypeParamName      = @"Authorization";
static NSString * const kSFOAuthAuthorizationTypeBasic          = @"Basic";

// OAuth Error Descriptions
// see https://na1.salesforce.com/help/doc/en/remoteaccess_oauth_refresh_token_flow.htm
// Deprecated: Use SFOAuthErrorCode enum instead.
static NSString * const kSFOAuthErrorTypeMalformedResponse      __deprecated_msg("Use SFOAuthErrorCode enum instead") = @"malformed_response";
static NSString * const kSFOAuthErrorTypeAccessDenied           __deprecated_msg("Use SFOAuthErrorCode enum instead") = @"access_denied";
static NSString * const KSFOAuthErrorTypeInvalidClientId        __deprecated_msg("Use SFOAuthErrorCode enum instead") = @"invalid_client_id"; // invalid_client_id:'client identifier invalid'
// this may be returned when the refresh token is revoked
// TODO: needs clarification
static NSString * const kSFOAuthErrorTypeInvalidClient          __deprecated_msg("Use SFOAuthErrorCode enum instead") = @"invalid_client";    // invalid_client:'invalid client credentials'
// this is returned when refresh token is revoked
static NSString * const kSFOAuthErrorTypeInvalidClientCredentials   __deprecated_msg("Use SFOAuthErrorCode enum instead") = @"invalid_client_credentials"; // this is documented but hasn't been witnessed
static NSString * const kSFOAuthErrorTypeInvalidGrant               __deprecated_msg("Use SFOAuthErrorCode enum instead") = @"invalid_grant";
static NSString * const kSFOAuthErrorTypeInvalidRequest             __deprecated_msg("Use SFOAuthErrorCode enum instead") = @"invalid_request";
static NSString * const kSFOAuthErrorTypeInactiveUser               __deprecated_msg("Use SFOAuthErrorCode enum instead") = @"inactive_user";
static NSString * const kSFOAuthErrorTypeInactiveOrg                __deprecated_msg("Use SFOAuthErrorCode enum instead") = @"inactive_org";
static NSString * const kSFOAuthErrorTypeRateLimitExceeded          __deprecated_msg("Use SFOAuthErrorCode enum instead") = @"rate_limit_exceeded";
static NSString * const kSFOAuthErrorTypeUnsupportedResponseType    __deprecated_msg("Use SFOAuthErrorCode enum instead") = @"unsupported_response_type";
static NSString * const kSFOAuthErrorTypeUnsupportedGrantType       __deprecated_msg("Use SFOAuthErrorCode enum instead") = @"unsupported_grant_type";
static NSString * const kSFOAuthErrorTypeTimeout                    __deprecated_msg("Use SFOAuthErrorCode enum instead") = @"auth_timeout";
static NSString * const kSFOAuthErrorTypeWrongVersion               __deprecated_msg("Use SFOAuthErrorCode enum instead") = @"wrong_version";     // credentials do not match current Connected App version in the org
static NSString * const kSFOAuthErrorTypeBrowserLaunchFailed        __deprecated_msg("Use SFOAuthErrorCode enum instead") = @"browser_launch_failed";
static NSString * const kSFOAuthErrorTypeUnknownAdvancedAuthConfig  __deprecated_msg("Use SFOAuthErrorCode enum instead") = @"unknown_advanced_auth_config";
static NSString * const kSFOAuthErrorTypeJWTLaunchFailed            __deprecated_msg("Use SFOAuthErrorCode enum instead") = @"jwt_launch_failed";
static NSString * const kSFOAuthErrorTypeAuthConfig                 __deprecated_msg("Use SFOAuthErrorCode enum instead") = @"auth_config";
static NSUInteger kSFOAuthReponseBufferLength                       = 512; // bytes
static NSString * const kHttpMethodPost                             = @"POST";
static NSString * const kHttpHeaderContentType                      = @"Content-Type";
static NSString * const kHttpPostContentType                        = @"application/x-www-form-urlencoded";
static NSString * const kHttpPostApplicationJsonContentType         = @"application/json";
static NSString * const kHttpHeaderUserAgent                        = @"User-Agent";
static NSString * const kHttpHeaderDPoP                             = @"DPoP";
static NSString * const kOAuthUserAgentUserDefaultsKey              = @"UserAgent";
static NSString * const kSFECParameter                              = @"ec";

// Endpoint path for Salesforce Identity API initialize headless, password-less login flow
static NSString * const kSFOAuthEndPointHeadlessInitPasswordlessLogin = @"services/auth/headless/init/passwordless/login";

/// Endpoint path for Salesforce Identity API initialize headless registration flow
static NSString * const kSFOAuthEndPointHeadlessInitRegistration = @"services/auth/headless/init/registration";

/// Endpoint path for Salesforce Identity API headless forgot password flow
static NSString * const kSFOAuthEndPointHeadlessForgotPassword = @"services/auth/headless/forgot_password";

// Standard login pool URLs (non-My Domain)
static NSString * const kSFOAuthProductionLoginURL               = @"login.salesforce.com";
static NSString * const kSFOAuthSandboxLoginURL                  = @"test.salesforce.com";
static NSString * const kSFOAuthWelcomeLoginURL                  = @"welcome.salesforce.com/discovery";

#endif /* SFSDKOAuthConstants_h */
